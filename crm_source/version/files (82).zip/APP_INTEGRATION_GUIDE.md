# 🔧 APP.PY ENTEGRASİON REHBERİ

## Durum: KRITIK

app.py'de **bootstrap_app()** fonksiyonu çağrılıyor ama tanımlı değil → **ModuleNotFoundError**

---

## 🎯 Çözüm (3 Adım)

### ADIM 1: Bootstrap Fonksiyonlarını Ekle

**Konum:** app.py'de satır 50 civarında (`app = Flask(__name__)` BAŞLATILMADAN ÖNCE)

**Eklenecek kod:** `app_missing_functions.py` dosyasının tamamı

**SONRA app = Flask(__name__)** bloğu gelir.

---

### ADIM 2: Global Değişkenleri Kontrol Et

app.py'nin basında şu import'lar MUTLAKA olmalı:

```python
from ai_listing import scrape_listing, analyze_listing, ai_listing_status, extract_contact_from_images
from buyer_engine import BuyerProfile, BuyerMatcher, ListingMatch, buyer_engine_status
```

✅ Zaten app.py'de var (line 5, 43)

---

### ADIM 3: bootstrap_app() Çağrısı Kontrol Et

app.py'nin sonunda şu satır VARSA, **KALDIR**:
```python
bootstrap_app()
```

Bunun yerine, if __name__ == "__main__" içinde çağır:

```python
if __name__ == "__main__":
    bootstrap_app()  # ← HER ZAMAN ÇAĞRıL
    
    port = int(os.environ.get("PORT", 5000))
    print(f"🚀 Unified Sunucu Başlatıldı: http://0.0.0.0:{port}")
    app.run(host="0.0.0.0", port=port, debug=False)
```

---

## 📋 Kontrol Listesi

- [ ] app_missing_functions.py'deki kod app.py'ye yapıştırıldı (satır 50'den sonra)
- [ ] `app = Flask(__name__)` SONRA tekrar görünüyor
- [ ] import'lar kontrol edildi (ai_listing, buyer_engine)
- [ ] bootstrap_app() sadece if __name__ == "__main__" içinde
- [ ] `python app.py` çalışıyor ve "Bootstrap Tamamlandı" görünüyor

---

## 🚀 Test Komut

```bash
python3 app.py
```

Beklenen çıktı:
```
======================================================================
🚀 NEXA CRM - Bootstrap Başlatılıyor
======================================================================

✅ Firebase Admin SDK başlatıldı
✅ Background Scheduler başlatıldı
📋 Listing refresh başladı: ...

======================================================================
✅ Bootstrap Tamamlandı
======================================================================

🚀 Unified Sunucu Başlatıldı: http://0.0.0.0:5000
   🌐 Web Sitesi : http://0.0.0.0:5000/
   📊 CRM Paneli : http://0.0.0.0:5000/crm
   🔧 Admin Panel: http://0.0.0.0:5000/admin
   🤖 AI Analiz  : http://0.0.0.0:5000/ai-analysis
   📂 Projeler   : http://0.0.0.0:5000/sunum
```

---

## ⚠️ Deprecated Dosyalar

Şu dosyalar **PRODUCTION'A DAHIL ETMEYİN**:

- ❌ `app_ai_additions.py` — içeriği app_missing_functions.py'ye taşınmıştır
- ❌ `eksik_fonksiyonlar.py` — referans amaçlı, production'a dahil etmeyin
- ✅ `app_missing_functions.py` — app.py'ye entegre edilmeli
- ✅ `test_buyer_engine.py` — test/QA için kullan

---

## 📞 Sorun Giderme

### Problem: "bootstrap_app not defined"
**Çözüm:** app_missing_functions.py'den bootstrap_app() ve diğer fonksiyonları app.py'ye ekle

### Problem: "Firebase bağlantısı başarısız"
**Çözüm:** 
- `service-account.json` dosyası bulunuyor mu?
- FIREBASE_SERVICE_ACCOUNT env var set edildi mi?

### Problem: "APScheduler yüklü değil"
**Çözüm:** `pip install apscheduler` (opsiyonel — warning'dir, kritik değil)

---

## 📦 Dosya Yapısı

```
/
├── app.py                           ← Ana uygulama (düzeltilmesi gerekli)
├── app_missing_functions.py         ← ✅ Bunu app.py'ye EKL
├── APP_INTEGRATION_GUIDE.md         ← Bu dosya
├── ai_listing.py
├── buyer_engine.py
├── fsbo_engine.py
├── mailer.py
├── valuation.py
├── wa_cloud.py
├── crm.html                         ← DIV'ler dengeli ✅
├── admin.html
├── ai_analysis.html
└── service-account.json             ← Firebase credential
```

---

## ✅ Testten Sonra

```bash
# Test suite çalıştır
python3 test_buyer_engine.py

# Tam API test (curl)
curl -X POST http://localhost:5000/api/ai/status \
  -H "Content-Type: application/json"
```

---

**Hazırlayan:** Nexa CRM Engineering  
**Tarih:** 21.05.2026  
**Durum:** 🔴 KRITIK — Hemen implement et
