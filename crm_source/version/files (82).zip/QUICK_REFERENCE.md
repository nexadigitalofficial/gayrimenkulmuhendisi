# ⚡ QUICK REFERENCE CARD

## 🎯 3 ADIMDA FIX

### STEP 1: Merge (10 min)
```bash
# app_missing_functions.py'nin tüm kodunu kopyala
# app.py'de satır 50'ye (app = Flask BAŞLATILMADAN ÖNCE) yapıştır
nano app.py
# CTRL+X, Save

# Kontrol
python3 app.py
```

Expected Output:
```
===============================================================
🚀 NEXA CRM - Bootstrap Başlatılıyor
===============================================================
✅ Bootstrap Tamamlandı
🚀 Unified Sunucu Başlatıldı: http://0.0.0.0:5000
```

### STEP 2: Test (2 min)
```bash
python3 test_buyer_engine.py
# ✅ TÜM TESTLER BAŞARILI
```

### STEP 3: Cleanup (5 min)
```bash
rm app_ai_additions.py
rm eksik_fonksiyonlar.py
rm fix_crm_divs.py
```

---

## 🚨 KRITIK DOSYALAR

| File | Action | Size | Status |
|------|--------|------|--------|
| **app_missing_functions.py** | ➕ MERGE TO app.py | ~400 lines | ✅ READY |
| **app.py** | ✏️ EDIT (add bootstrap) | 3152 lines | 🔴 PENDING |
| **crm.html** | ✅ NO CHANGE | 6768 lines | ✅ HEALTHY |
| **app_ai_additions.py** | ❌ DELETE | ~130 lines | 🗑️ DEPRECATED |
| **eksik_fonksiyonlar.py** | ❌ DELETE | ~230 lines | 🗑️ DEPRECATED |
| **fix_crm_divs.py** | ❌ DELETE | ~150 lines | 🗑️ DEPRECATED |

---

## ✅ CHECKLIST

- [ ] Step 1: Merge app_missing_functions.py → app.py
- [ ] Step 2: Test (`python3 app.py`)
- [ ] Step 3: Run tests (`python3 test_buyer_engine.py`)
- [ ] Step 4: Delete deprecated files (3x rm)
- [ ] Step 5: Git commit & push

---

## 🔧 COMMON ERRORS & FIXES

### Error: "ModuleNotFoundError: No module named 'bootstrap_app'"
```python
# ❌ WRONG: Missing import
bootstrap_app()

# ✅ CORRECT: Merge app_missing_functions.py first
# Then bootstrap_app() defined locally in app.py
```
**Fix:** Follow STEP 1

---

### Error: "Firebase not initialized"
```python
# ✅ Automatic: init_firebase_admin() runs in bootstrap_app()
# Check: service-account.json exists in project root
```
**Fix:** Ensure service-account.json path correct (env var)

---

### Error: "APScheduler not installed"
```
⚠️  WARNING (not critical)
Fix: pip install apscheduler
```

---

## 📊 FILE SUMMARY

### ✅ KEEP (Production)
```
app.py .......................... Main app (EDIT: add bootstrap)
crm.html ........................ DIV balance OK (612:612) ✅
ai_listing.py ................... AI engine ✅
buyer_engine.py ................ Buyer matching ✅
```

### 📋 MERGE
```
app_missing_functions.py ........ INTO app.py (sat.50) ✅
test_buyer_engine.py ........... Keep for testing ✅
```

### ❌ DELETE
```
app_ai_additions.py ............ DEPRECATED
eksik_fonksiyonlar.py ......... DEPRECATED  
fix_crm_divs.py ............... DEPRECATED
```

---

## 🧪 TEST COMMANDS

```bash
# Bootstrap test
python3 app.py

# Unit tests
python3 test_buyer_engine.py

# API health
curl -X GET http://localhost:5000/api/ai/status

# CRM HTML DIV count
curl -s http://localhost:5000/crm | grep -o '<div' | wc -l
# Expected: 612
```

---

## 📱 CRITICAL LINES IN app.py

### FIND (line ~50)
```python
app = Flask(__name__)
```

### INSERT BEFORE (add 400 lines from app_missing_functions.py)
```python
# Global state
_scheduler = None
_bootstrap_done = False
_fb_initialized = False
db_admin = None

def init_firebase_admin(): ...
def start_scheduler(): ...
def bootstrap_app(): ...
# ... (full content)

# ↓ THEN app = Flask ...
app = Flask(__name__)
```

### VERIFY (line ~6765)
```python
if __name__ == "__main__":
    bootstrap_app()  # ← Must be here
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
```

---

## 🚀 DEPLOYMENT COMMAND

```bash
# 1. Merge & test locally
python3 app.py
python3 test_buyer_engine.py

# 2. Git commit
git add app.py
git add -u  # (delete deprecated)
git commit -m "Fix: Merge bootstrap functions, cleanup deprecated files"

# 3. Push
git push origin main

# 4. Render/production deploy (auto-triggered or manual)
```

---

## 📞 SUPPORT

**Can't merge?**
→ See APP_INTEGRATION_GUIDE.md (3-step detail)

**Want to archive instead?**
→ See CLEANUP_DEPRECATED_FILES.md (Scenario 2)

**Need to validate HTML?**
→ See CRM_HTML_ANALYSIS.md (DIV confirmed 612:612)

**Run tests?**
→ `python3 test_buyer_engine.py`

---

## ⏰ TIMING

| Task | Time |
|------|------|
| Read this card | 2 min |
| Merge app.py | 8 min |
| Test bootstrap | 3 min |
| Run tests | 2 min |
| Delete deprecated | 2 min |
| **TOTAL** | **17 min** |

---

## ✅ SUCCESS SIGNAL

```
✅ python3 app.py runs
✅ "Bootstrap Tamamlandı" appears
✅ Server starts on :5000
✅ test_buyer_engine.py passes
✅ 3 deprecated files removed
✅ crm.html loads (no errors)
```

**Status: 🟢 READY TO DEPLOY**

---

**Version:** 1.0  
**Date:** 21.05.2026  
**Status:** APPROVED
