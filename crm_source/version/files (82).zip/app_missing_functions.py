# ================================================================
# app.py'YE DOĞRUDAN EKLENECEk BÖLÜMLER
# ================================================================
# Bu dosya app.py'nin import satırlarından (line ~50) sonra,
# Flask app = Flask(__name__) BAŞLATILMADAN ÖNCE insert edilmeli
#
# DIKKAT: Tam dosya değildir — sadece eksik parçalar!
# app.py'nin 51. satırından SONRA, kod başlamadan ÖNCE insert et
# ================================================================

import os
import logging
from datetime import datetime, timezone

# ── SCHEDULER IMPORT ─────────────────────────────────────────
try:
    from apscheduler.schedulers.background import BackgroundScheduler
    from apscheduler.triggers.interval import IntervalTrigger
    _apscheduler_available = True
except ImportError:
    _apscheduler_available = False
    print("⚠️  APScheduler yüklü değil: pip install apscheduler")

# ── GLOBAL STATE ─────────────────────────────────────────────
_scheduler = None
_listing_cache_time = None
_bootstrap_done = False
_fb_initialized = False
db_admin = None


# ================================================================
# BOOTSTRAP FONKSIYONLARI
# ================================================================

def init_firebase_admin():
    """
    Firebase Admin SDK'yı başlat.
    
    Gerekli ortam değişkenleri:
      FIREBASE_SERVICE_ACCOUNT  → service-account.json dosyasının yolu
    """
    global _fb_initialized, db_admin
    
    # Zaten başlatılmışsa, tekrar başlatma
    if _fb_initialized:
        return
    
    try:
        # Service account dosyasının yolunu al
        service_account_path = os.environ.get(
            "FIREBASE_SERVICE_ACCOUNT", 
            "service-account.json"
        )
        
        # Dosya kontrol et
        if not os.path.exists(service_account_path):
            print(f"⚠️  Firebase credential dosyası bulunamadı: {service_account_path}")
            print("   Beklenen konum: service-account.json (ya da FIREBASE_SERVICE_ACCOUNT env var)")
            _fb_initialized = False
            return
        
        # Firebase Admin SDK başlat
        from firebase_admin import credentials, firestore as admin_firestore
        
        cred = credentials.Certificate(service_account_path)
        
        # Eğer zaten initialize edilmişse, hatayı yakla
        try:
            firebase_admin.initialize_app(cred)
        except ValueError:
            # Zaten initialize edilmiş
            pass
        
        db_admin = admin_firestore.client()
        _fb_initialized = True
        
        print("✅ Firebase Admin SDK başlatıldı")
        print(f"   📁 Credential: {service_account_path}")
        
    except Exception as e:
        print(f"❌ Firebase başlatma hatası: {e}")
        print("   Çözüm: Firebase credential dosyasını kontrol et")
        _fb_initialized = False


def start_scheduler():
    """
    APScheduler'ı başlat (follow-up notifications, otomatik refresh vb. için).
    """
    global _scheduler
    
    # Zaten başlatılmışsa
    if _scheduler is not None:
        return
    
    if not _apscheduler_available:
        print("⚠️  APScheduler yüklü değil, background tasks deaktif")
        return
    
    try:
        _scheduler = BackgroundScheduler(daemon=True)
        
        # İsteğe bağlı: Scheduler job'larını ekle
        # Not: Bu fonksiyonlar tanımlanmalıdır
        
        # Örnek 1: Listeleri 5 dakikada bir yenile
        # _scheduler.add_job(
        #     func=_refresh_listings_bg,
        #     trigger=IntervalTrigger(minutes=5),
        #     id="refresh_listings",
        #     name="Refresh listings from scrapers",
        #     replace_existing=True
        # )
        
        _scheduler.start()
        print("✅ Background Scheduler başlatıldı")
        
    except Exception as e:
        print(f"❌ Scheduler başlatma hatası: {e}")
        _scheduler = None


def _refresh_listings_bg():
    """
    Listeleri arka planda yenile.
    
    Bu fonksiyon scheduler tarafından çağrılır.
    """
    global _listing_cache_time
    
    try:
        current_time = datetime.now(timezone.utc).isoformat()
        _listing_cache_time = current_time
        
        print(f"📋 Listing refresh başladı: {current_time}")
        
    except Exception as e:
        print(f"⚠️  Listing refresh hatası: {e}")


def check_bootstrap_status() -> dict:
    """Bootstrap durumunu kontrol et."""
    return {
        "ok": _bootstrap_done,
        "firebase_initialized": _fb_initialized,
        "scheduler_running": _scheduler is not None and _scheduler.running,
        "last_listing_refresh": _listing_cache_time,
    }


def bootstrap_app():
    """
    Uygulamayı başlat — tüm servisleri initialize et.
    
    Bu fonksiyon app.py'nin sonunda, if __name__ == "__main__" 
    bloğundan ÖNCE çağrılır.
    """
    global _bootstrap_done
    
    # Zaten çalıştırılmışsa, tekrar çalıştırma
    if _bootstrap_done:
        return
    
    print("\n" + "="*70)
    print("🚀 NEXA CRM - Bootstrap Başlatılıyor")
    print("="*70 + "\n")
    
    # 1. Firebase
    init_firebase_admin()
    
    # 2. Scheduler
    start_scheduler()
    
    # 3. Listing cache
    _refresh_listings_bg()
    
    # 4. Mark complete
    _bootstrap_done = True
    
    print("\n" + "="*70)
    print("✅ Bootstrap Tamamlandı")
    print("="*70 + "\n")


# ================================================================
# AI ANALIZ ROTALARINI EKLE
# ================================================================

@app.route("/ai-analysis")
def ai_analysis_page():
    """AI Gayrimenkul Analiz sayfası."""
    try:
        return send_file("ai_analysis.html")
    except Exception as e:
        return f"ai_analysis.html bulunamadı: {e}", 404


@app.route("/api/ai/scrape", methods=["POST"])
def api_ai_scrape():
    """
    İlan URL'sini scrape eder.
    Body: {"url": "https://www.sahibinden.com/ilan/..."}
    """
    body = flask_request.json or {}
    url  = (body.get("url") or "").strip()

    if not url:
        return jsonify({"ok": False, "error": "url boş olamaz"}), 400

    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    try:
        result = scrape_listing(url)
        return jsonify({"ok": result.get("ok", False), "data": result})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


@app.route("/api/ai/analyze", methods=["POST"])
def api_ai_analyze():
    """
    Gemini ile tam gayrimenkul analizi üretir.

    Body (JSON):
    {
      "listing_data":    { ... }  // /api/ai/scrape çıktısı (opsiyonel)
      "manual_data": {            // Manuel giriş alanları (opsiyonel)
        "manual_price":    "5.500.000 TL",
        "manual_area":     "120 m²",
        ...
      },
      "uploaded_images": ["data:image/jpeg;base64,...", ...]   // opsiyonel
    }
    """
    body = flask_request.json or {}

    listing_data    = body.get("listing_data")
    manual_data     = body.get("manual_data")
    uploaded_images = body.get("uploaded_images", [])

    # En az bir girdi gerekli
    if not listing_data and not manual_data and not uploaded_images:
        return jsonify({"ok": False, "error": "En az bir girdi gerekli (listing_data, manual_data veya uploaded_images)"}), 400

    try:
        result = analyze_listing(
            listing_data    = listing_data,
            manual_data     = manual_data,
            uploaded_images = uploaded_images,
        )
        status = 200 if result.get("ok") else 500
        return jsonify(result), status
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


@app.route("/api/ai/status")
def api_ai_status():
    """Gemini AI listing modülünün konfigürasyon durumunu döner."""
    return jsonify(ai_listing_status())


@app.route("/api/ai/save-to-crm", methods=["POST"])
def api_ai_save_to_crm():
    """
    Üretilen analiz raporunu Firebase'e kaydeder.

    Body: {
      "uid":    "kullanici_id",
      "report": { ... },
      "url":    "ilan_url",
      "contact_id": "..."
    }
    """
    if not _fb_initialized:
        return jsonify({"ok": False, "error": "Firebase bağlı değil"}), 503

    body       = flask_request.json or {}
    uid        = body.get("uid")
    report     = body.get("report")
    url        = body.get("url", "")
    contact_id = body.get("contact_id", "")

    if not uid or not report:
        return jsonify({"ok": False, "error": "uid ve report gerekli"}), 400

    try:
        doc_ref = (
            db_admin
            .collection("users").document(uid)
            .collection("ai_analyses")
            .document()
        )
        doc_ref.set({
            "report":     report,
            "url":        url,
            "contactId":  contact_id,
            "createdAt":  datetime.now(timezone.utc).isoformat(),
            "source":     report.get("data_source", ""),
            "verdict":    report.get("recommendation", {}).get("verdict", ""),
        })
        return jsonify({"ok": True, "id": doc_ref.id})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


@app.route("/api/crm/extract-contact", methods=["POST"])
def api_crm_extract_contact():
    """
    Ekran görüntülerinden ad soyad + telefon çıkarır (Gemini Vision).

    Body: {
      "images": ["data:image/jpeg;base64,...", ...]   // maks 3 görüntü
    }
    """
    from ai_listing import extract_contact_from_images

    body   = flask_request.json or {}
    images = body.get("images", [])

    if not images:
        return jsonify({"ok": False, "error": "images listesi boş"}), 400

    if not isinstance(images, list):
        return jsonify({"ok": False, "error": "images bir liste olmalı"}), 400

    try:
        result = extract_contact_from_images(images)
        status = 200 if result.get("ok") else 500
        return jsonify(result), status
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500
