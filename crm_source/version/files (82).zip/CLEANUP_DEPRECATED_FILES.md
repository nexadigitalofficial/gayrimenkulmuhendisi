# 🗑️ DEPRECATED DOSYALAR — CLEANUP REHBERI

## Durum
Geliştirme sırasında ortaya çıkan **3 deprecated referans dosya** production'ı karıştırıyor.

---

## 📋 Deprecated Dosya Listesi

### 1. ❌ `app_ai_additions.py`

**Durum:** DEPRECATED — Content app_missing_functions.py'ye merge edildi

**İçeriği:**
- `/ai-analysis` sayfası rotası
- `/api/ai/scrape` API
- `/api/ai/analyze` API
- `/api/ai/status` API
- `/api/ai/save-to-crm` API
- `/api/crm/extract-contact` API

**Eylem:**
```bash
# OPTION 1: Tamamen sil
rm app_ai_additions.py

# OPTION 2: Arşiv et (referans için)
git mv app_ai_additions.py .archived/app_ai_additions.py

# OPTION 3: Dokümantasyon oluştur (geçmiş için)
echo "DEPRECATED: See app_missing_functions.py for final implementation" > app_ai_additions.py
```

**Neden deprecated:**
- İçeriği app_missing_functions.py'ye taşındı
- app.py'ye doğrudan entegre edilecek
- Ayrı dosya → confusion ve divergence riski

---

### 2. ❌ `eksik_fonksiyonlar.py`

**Durum:** DEPRECATED — Reference amaçlı

**İçeriği:**
- `init_firebase_admin()` — bootstrap
- `start_scheduler()` — background tasks
- `bootstrap_app()` — orchestrator
- Test fonksiyonları

**Eylem:**
```bash
# OPTION 1: Sil
rm eksik_fonksiyonlar.py

# OPTION 2: Archive
git mv eksik_fonksiyonlar.py .archived/

# OPTION 3: Readonly yapı
chmod 444 eksik_fonksiyonlar.py
```

**Neden deprecated:**
- Content app_missing_functions.py'ye merge edildi
- Production'da double code riski
- Reference amaçlı → documentation'a taşındı

---

### 3. ❌ `fix_crm_divs.py`

**Durum:** DEPRECATED — DIV'ler düzeltildi

**İçeriği:**
- DIV mismatch analyzer
- HTML debugging tools

**Eylem:**
```bash
# OPTION 1: Sil
rm fix_crm_divs.py

# OPTION 2: Archive
git mv fix_crm_divs.py .archived/

# OPTION 3: Docs
echo "DEPRECATED: DIV analysis — see crm.html check results" > fix_crm_divs.py
```

**Neden deprecated:**
- crm.html DIV'leri dengeli ✅
- Script artık gerekli değil
- Başka HTML'lerde veya future debugging'de yeniden yazılabilir

---

## ✅ Tutulması Gereken Dosyalar

### Production-Ready

```bash
✅ app.py                       ← Ana uygulama (requires app_missing_functions.py merge)
✅ app_missing_functions.py     ← Bootstrap + AI API routes (app.py'ye eklenecek)
✅ crm.html                     ← Vue.js CRM (DIV'ler dengeli)
✅ admin.html                   ← Admin panel
✅ ai_analysis.html             ← AI analiz sayfası
✅ buyer_panel.html             ← Alıcı paneli
✅ ai_listing.py                ← AI listing analysis engine
✅ buyer_engine.py              ← Buyer matching engine
✅ fsbo_engine.py               ← FSBO analysis
✅ mailer.py                    ← Email service
✅ valuation.py                 ← Valuation report generator
✅ wa_cloud.py                  ← WhatsApp Cloud API
```

### Testing Only

```bash
🧪 test_buyer_engine.py         ← Unit tests (git'e ekle, production ignore)
```

---

## 🚀 Cleanup Stratejisi

### Senaryo 1: Agresif Cleanup (Tavsiye Edilir)

```bash
# 1. Production değil, deprecated'leri sil
rm app_ai_additions.py
rm eksik_fonksiyonlar.py
rm fix_crm_divs.py

# 2. app_missing_functions.py'yi app.py'ye merge et
cat app_missing_functions.py | head -200 >> app.py

# 3. Kontrol et
python3 app.py

# 4. Cleanup
rm app_missing_functions.py
```

### Senaryo 2: Archive + Referans

```bash
# 1. Archive klasörü oluştur
mkdir -p .archived

# 2. Deprecated dosyaları taşı
git mv app_ai_additions.py .archived/
git mv eksik_fonksiyonlar.py .archived/
git mv fix_crm_divs.py .archived/

# 3. .gitignore'a ekle
echo ".archived/" >> .gitignore

# 4. app_missing_functions.py'yi app.py'ye merge et
# (Senaryo 1 Step 2)
```

### Senaryo 3: In-Place Disable (Eğer emin değilsen)

```bash
# 1. Rename dengan prefix (production ignore)
mv app_ai_additions.py _DEPRECATED_app_ai_additions.py
mv eksik_fonksiyonlar.py _DEPRECATED_eksik_fonksiyonlar.py
mv fix_crm_divs.py _DEPRECATED_fix_crm_divs.py

# 2. .gitignore'a ekle
echo "_DEPRECATED_*" >> .gitignore

# 3. Referans için README ekle
```

---

## 📋 Pre-Cleanup Kontrol Listesi

- [ ] app_missing_functions.py'nin tüm kodu app.py'ye merge edilecek
- [ ] app.py test edilecek (`python3 app.py`)
- [ ] Bootstrap "tamamlandı" mesajı görüntülenir
- [ ] test_buyer_engine.py çalışır (`python3 test_buyer_engine.py`)
- [ ] crm.html tarayıcıda açılır — DIV error yok
- [ ] GitHub'a commit: "Remove deprecated files after cleanup"

---

## 🔍 Cleanup Sonrası Doğrulama

```bash
# Deprecated dosya kalmadı mı?
ls -la | grep -E "(app_ai_additions|eksik_fonksiyonlar|fix_crm_divs)"
# (Çıktı boş olmalı)

# app.py çalışıyor mu?
python3 app.py
# Beklenen: "Bootstrap Tamamlandı" + "🚀 Sunucu Başlatıldı"

# Tüm import'lar çalışıyor mu?
python3 -c "from app import *; print('✅ All imports OK')"

# Test suite geçiyor mu?
python3 test_buyer_engine.py
```

---

## 📊 Dosya Döngüsü Özeti

```
DEV PHASE                MERGE PHASE              CLEANUP PHASE
┌──────────────┐        ┌──────────────┐        ┌──────────────┐
│ eksik_    │ ────→ │ app_missing  │ ──────→ │ DELETED/    │
│ fonksiyonlar│        │ _functions   │        │ ARCHIVED    │
└──────────────┘        └──────────────┘        └──────────────┘
│ app_ai_      │ ──────┼ (content merge) ───────────┼
│ additions    │        │                         │
└──────────────┘        │                         │
│ fix_crm_     │ ──────┴────────────────────────────→
│ divs         │        (no longer needed)
└──────────────┘
```

---

## ✅ Cleanup Tamamlandı Sinyali

```
✅ app.py production-ready
✅ Bootstrap fonksiyonları integrated
✅ All AI routes working
✅ Deprecated files removed/archived
✅ Tests passing
✅ GitHub commit mesajı: "Cleanup deprecated files"
```

---

**Hazırlayan:** Nexa CRM Engineering  
**Önerilen Zaman:** İmmediately after app.py merge  
**Başlangıç:** Senaryo 1 (Agresif) — güvenli ve temiz
